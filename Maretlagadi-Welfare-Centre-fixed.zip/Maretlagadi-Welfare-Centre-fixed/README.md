# Maretlagadi Welfare Centre

## PayFast donation flow

The donation system is configured for the PayFast Sandbox.

Sandbox credentials:
- Merchant ID: `10000100`
- Merchant Key: `46f0cd694581a`
- Passphrase: `jt7NOE43FZPn`

The donation is first stored as `pending`. A PayFast ITN then verifies the signature, validates the transaction with PayFast, checks the amount against the original donation, and changes the donation to `complete`.

### Local XAMPP testing

The customer return page works on localhost. PayFast **cannot send an ITN to localhost**.

To test automatic `pending -> complete` updates from your local machine, expose the project with a public HTTPS tunnel (such as ngrok), then change `$pf_base_url` in `Pages/donation.php` to the public URL.

Example:
`https://YOUR-PUBLIC-URL/Pages`

Then the notify URL becomes:
`https://YOUR-PUBLIC-URL/Pages/donation_itn.php`

### Going live

Before production:
1. Set `$pf_testing_mode = false` in `Pages/donation.php`.
2. Replace the sandbox merchant ID/key/passphrase with your own live PayFast credentials.
3. Set `$pf_base_url` to the real HTTPS domain.
4. Make sure `donation_itn.php` is publicly reachable over HTTPS.
5. Test the complete payment flow before accepting real donations.

Do not commit live PayFast credentials to a public GitHub repository.
