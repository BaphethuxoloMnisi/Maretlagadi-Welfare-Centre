<?php
// Shared admin password for the dashboard.
// IMPORTANT: Change this password, then regenerate the hash below and
// replace ADMIN_PASSWORD_HASH with the new value. Never store the plain
// password in code.
//
// To generate a new hash, run this once (e.g. in a throwaway PHP file or CLI):
//   echo password_hash('your-new-password', PASSWORD_DEFAULT);

// Admin password hash.
define('ADMIN_PASSWORD_HASH', '$2y$12$zbne2A5J3d2qtNJyP.YMHuWvG71eYe8Zj9iTYjf9rXCsCK7bEX.BS');