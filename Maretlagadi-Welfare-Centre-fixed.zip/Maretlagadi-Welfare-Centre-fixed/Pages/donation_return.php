<?php
include '../navigation-bar/navbar.php';
include '../database/create_database.php';

$m_payment_id = trim($_GET['m_payment_id'] ?? '');
$status = null;

if ($m_payment_id !== '') {
    $stmt = mysqli_prepare($conn, "SELECT payment_status, amount FROM donations WHERE m_payment_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $m_payment_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $status = mysqli_fetch_assoc($result) ?: null;
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Result | Maretlagadi Welfare Centre</title>
    <style>
        .result-card { max-width: 700px; margin: 80px auto; }
    </style>
</head>
<body>
<div class="container">
    <div class="card shadow-sm border-0 result-card">
        <div class="card-body p-5 text-center">
            <?php if ($status && $status['payment_status'] === 'complete'): ?>
                <h2 class="text-success mb-3">Thank You for Your Donation!</h2>
                <p>Your payment of <strong>R<?php echo number_format((float)$status['amount'], 2); ?></strong> was confirmed successfully.</p>
            <?php elseif ($status && $status['payment_status'] === 'pending'): ?>
                <h2 class="text-success mb-3">Thank You!</h2>
                <p>Your payment was submitted. We are waiting for PayFast to confirm the transaction.</p>
                <p class="text-muted">Your donation reference is <strong><?php echo htmlspecialchars($m_payment_id); ?></strong>.</p>
            <?php else: ?>
                <h2 class="text-success mb-3">Thank You!</h2>
                <p>We received your return from PayFast. Your donation status will be confirmed shortly.</p>
            <?php endif; ?>
            <a href="index.php" class="btn btn-success mt-3">Return to Home</a>
        </div>
    </div>
</div>
<?php include '../footer/footer.php'; ?>
</body>
</html>
