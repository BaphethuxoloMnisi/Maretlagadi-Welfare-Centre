<?php
/**
 * PayFast Instant Transaction Notification (ITN)
 *
 * IMPORTANT:
 * PayFast must be able to reach this file over the public Internet.
 * localhost will not receive ITNs. For local testing use a public HTTPS
 * tunnel and put its URL into donation.php.
 */

header('HTTP/1.0 200 OK');
flush();

include '../database/create_database.php';

$passphrase = 'jt7NOE43FZPn';
$pfHost = 'sandbox.payfast.co.za';

$pfData = $_POST;

if (empty($pfData)) {
    http_response_code(400);
    exit('No notification data received.');
}

// Remove escaping added by older PHP configurations.
foreach ($pfData as $key => $val) {
    $pfData[$key] = is_string($val) ? stripslashes($val) : $val;
}

// Build the exact parameter string in the order PayFast posted the fields,
// excluding the signature.
$pfParamString = '';
foreach ($pfData as $key => $val) {
    if ($key === 'signature') {
        continue;
    }
    if ($val !== '') {
        $pfParamString .= $key . '=' . urlencode(trim((string)$val)) . '&';
    }
}
$pfParamString = rtrim($pfParamString, '&');

$calculatedSignature = md5($pfParamString . '&passphrase=' . urlencode(trim($passphrase)));

if (!isset($pfData['signature']) || !hash_equals($pfData['signature'], $calculatedSignature)) {
    http_response_code(400);
    exit('Invalid signature.');
}

// Confirm the notification came from PayFast.
$validHosts = [
    'www.payfast.co.za',
    'sandbox.payfast.co.za',
    'w1w.payfast.co.za',
    'w2w.payfast.co.za'
];

$validIps = [];
foreach ($validHosts as $host) {
    $ips = gethostbynamel($host);
    if ($ips !== false) {
        $validIps = array_merge($validIps, $ips);
    }
}
$validIps = array_unique($validIps);

$remoteIp = $_SERVER['REMOTE_ADDR'] ?? '';
if ($remoteIp !== '' && !empty($validIps) && !in_array($remoteIp, $validIps, true)) {
    http_response_code(400);
    exit('Invalid source.');
}

// Confirm the transaction with PayFast's server.
if (!function_exists('curl_init')) {
    http_response_code(500);
    exit('PHP cURL extension is required for PayFast ITN validation.');
}

$ch = curl_init('https://' . $pfHost . '/eng/query/validate');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HEADER => false,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $pfParamString,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_TIMEOUT => 20,
    CURLOPT_USERAGENT => 'Maretlagadi-Welfare-Centre/1.0'
]);
$response = curl_exec($ch);
$curlError = curl_error($ch);
curl_close($ch);

if ($response !== 'VALID') {
    http_response_code(400);
    exit('PayFast validation failed.' . ($curlError ? ' ' . $curlError : ''));
}

$m_payment_id = trim($pfData['m_payment_id'] ?? '');
$payment_status = strtoupper(trim($pfData['payment_status'] ?? ''));
$pf_payment_id = trim($pfData['pf_payment_id'] ?? '');
$amount_gross = (float)($pfData['amount_gross'] ?? 0);

if ($m_payment_id === '') {
    http_response_code(400);
    exit('Missing payment ID.');
}

// Check that the amount matches the amount originally requested.
$stmt = mysqli_prepare($conn, "SELECT amount FROM donations WHERE m_payment_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 's', $m_payment_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$donation = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$donation) {
    http_response_code(404);
    exit('Donation not found.');
}

if (abs((float)$donation['amount'] - $amount_gross) > 0.01) {
    http_response_code(400);
    exit('Donation amount mismatch.');
}

if ($payment_status === 'COMPLETE') {
    $stmt = mysqli_prepare(
        $conn,
        "UPDATE donations
         SET payment_status = 'complete', pf_payment_id = ?
         WHERE m_payment_id = ?"
    );
    mysqli_stmt_bind_param($stmt, 'ss', $pf_payment_id, $m_payment_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
} elseif ($payment_status === 'CANCELLED') {
    $stmt = mysqli_prepare(
        $conn,
        "UPDATE donations SET payment_status = 'cancelled', pf_payment_id = ?
         WHERE m_payment_id = ? AND payment_status <> 'complete'"
    );
    mysqli_stmt_bind_param($stmt, 'ss', $pf_payment_id, $m_payment_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

echo 'OK';
?>
