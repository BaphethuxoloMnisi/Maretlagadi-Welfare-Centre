# Maretlagadi Welfare Centre - Android App

Android Studio (Kotlin) implementation of the Maretlagadi Welfare Centre
Digital Platform mobile app, built for WDP33 - SS2 Assignment 2 (Group
4Lifer's). This covers the modules described in the assignment
documentation: public access, authentication, volunteer management,
programme/event management, communication (notifications + contact
enquiries), donations, and the administrator module.

## Opening the project

1. Open Android Studio (Koala/2024.1 or newer recommended).
2. **File > Open** and select this project's root folder.
3. Let Gradle sync. If Android Studio reports the Gradle wrapper JAR is
   missing, click the prompt to let it download/regenerate it (this is
   normal - the binary wrapper JAR isn't included in this handoff).
4. Run on an emulator or device with **minSdk 26 (Android 8.0)** or higher.

## Database

The app uses **Room** (SQLite under the hood) entirely on-device - no
backend server is required to demo the app. This mirrors the table
design from section 2.3 of the documentation:

| Table | Entity file |
|---|---|
| users | `data/entities/User.kt` |
| volunteers | `data/entities/Volunteer.kt` |
| programmes | `data/entities/Programme.kt` |
| events | `data/entities/Event.kt` |
| volunteer_shifts | `data/entities/VolunteerShift.kt` |
| messages | `data/entities/EnquiryMessage.kt` |
| notifications | `data/entities/Notification.kt` |
| donations | `data/entities/Donation.kt` |

`data/AppDatabase.kt` defines the Room database and seeds it on first
launch with sample programmes/events and one administrator account so
the app is demoable immediately:

- **Admin login:** `admin@maretlagadi.org` / `Admin@123`

Passwords are never stored as plain text - `utils/PasswordUtils.kt`
salts and hashes every password (SHA-256, per-user random salt, 10,000
iterations) before it touches the database, per the security
requirement in section 2.6 of the documentation.

If your group wants the app to talk to the PHP/MySQL backend the web
team is building instead of the on-device database, swap the
implementation inside `repository/WelfareRepository.kt` for Retrofit/API
calls - the rest of the app (ViewModels, Fragments) only talks to the
repository, so no UI code needs to change.

## Architecture

- **MVVM**: `ui/auth/AuthViewModel.kt` is the one ViewModel in this build
  (auth screens); the other screens read/write directly through
  `repository/WelfareRepository.kt` inside `lifecycleScope.launch { }`
  blocks, which is enough for this project's scope but can be split into
  per-screen ViewModels the same way if your group wants that consistently.
- **Navigation Component** (`res/navigation/nav_graph.xml`) drives all
  screens from a single `MainActivity`; a `BottomNavigationView` covers
  Home, Programmes, Volunteer, Notifications and Profile.
- **Room + Kotlin Coroutines/Flow** for persistence.
- **View Binding** (no findViewById).
- Public content (Home, Programmes, Events) is reachable without an
  account; Volunteer, Notifications and Profile prompt for login,
  matching section 1.1 of the documentation.

## Project structure

```
app/src/main/java/com/maretlagadi/welfarecentre/
├── WelfareApp.kt              # Application class (DB/repo/session singletons)
├── MainActivity.kt
├── data/                      # Room entities, DAOs, AppDatabase, seed data
├── repository/                # WelfareRepository - single data access point
├── utils/                     # PasswordUtils, InputValidator, SessionManager
└── ui/
    ├── auth/                  # Login, Register, Forgot Password
    ├── home/
    ├── programmes/
    ├── events/
    ├── volunteer/             # Registration + shift sign-up dashboard
    ├── notifications/
    ├── contact/                # Contact Us / enquiry form
    ├── donations/
    ├── profile/                # Edit profile, change password, logout
    └── admin/                  # Dashboard, manage users/programmes/events/enquiries
```

## What's implemented vs. left for your group

Implemented and working end-to-end: registration/login (hashed
passwords), password reset, guest browsing, viewing programmes and
events, volunteer registration + shift sign-up, notifications, the
contact form, a donation info + logging screen, profile editing +
password change + logout, and an admin area to manage users, programmes,
events and view enquiries.

Left as placeholders for the group to fill in (matches the `[Insert ...]`
placeholders in the documentation): app icon/branding artwork, real
banking details on the Donations screen, and screenshots for the
documentation. If your lecturer wants live push notifications, that's
the one piece that would need Firebase Cloud Messaging wired in on top
of this (the `notifications` table and screen already work locally).
