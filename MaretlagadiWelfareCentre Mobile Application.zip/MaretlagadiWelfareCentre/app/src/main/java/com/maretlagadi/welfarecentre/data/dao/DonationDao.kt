package com.maretlagadi.welfarecentre.data.dao

import androidx.room.*
import com.maretlagadi.welfarecentre.data.entities.Donation
import kotlinx.coroutines.flow.Flow

@Dao
interface DonationDao {
    @Insert
    suspend fun insert(donation: Donation): Long

    @Query("SELECT * FROM donations ORDER BY date DESC")
    fun getAllDonations(): Flow<List<Donation>>
}
