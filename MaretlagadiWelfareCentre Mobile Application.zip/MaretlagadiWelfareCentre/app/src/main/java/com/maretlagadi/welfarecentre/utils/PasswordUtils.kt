package com.maretlagadi.welfarecentre.utils

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Handles password hashing so that plain-text passwords are never stored,
 * per the security requirement described in section 2.6 (Security
 * Considerations): "Passwords should be protected using secure hashing
 * techniques rather than stored in readable plain text."
 *
 * A random salt is generated per user and stored alongside the hash so
 * that identical passwords do not produce identical hashes.
 */
object PasswordUtils {

    private const val ITERATIONS = 10_000

    /** Returns a Pair(hash, salt), both hex-encoded. */
    fun hashPassword(password: String): Pair<String, String> {
        val salt = generateSalt()
        val hash = hashWithSalt(password, salt)
        return Pair(hash, salt)
    }

    fun verifyPassword(password: String, storedHash: String, storedSalt: String): Boolean {
        val hash = hashWithSalt(password, storedSalt)
        return hash == storedHash
    }

    private fun generateSalt(): String {
        val random = SecureRandom()
        val saltBytes = ByteArray(16)
        random.nextBytes(saltBytes)
        return saltBytes.joinToString("") { "%02x".format(it) }
    }

    private fun hashWithSalt(password: String, salt: String): String {
        var result = "$salt:$password"
        val digest = MessageDigest.getInstance("SHA-256")
        repeat(ITERATIONS) {
            result = digest.digest(result.toByteArray()).joinToString("") { "%02x".format(it) }
        }
        return result
    }
}
