package com.maretlagadi.welfarecentre.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * donations table - records where applicable, per the Donation Module.
 */
@Entity(tableName = "donations")
data class Donation(
    @PrimaryKey(autoGenerate = true) val donationId: Long = 0,
    val userId: Long?,
    val donorName: String,
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val reference: String
)
