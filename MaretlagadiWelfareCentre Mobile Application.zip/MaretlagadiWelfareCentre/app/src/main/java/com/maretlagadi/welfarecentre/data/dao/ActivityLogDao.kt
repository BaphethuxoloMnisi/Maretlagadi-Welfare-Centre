package com.maretlagadi.welfarecentre.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.maretlagadi.welfarecentre.data.entities.ActivityLog
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Insert
    suspend fun insert(log: ActivityLog): Long

    @Query("SELECT * FROM activity_log ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ActivityLog>>

    @Query("SELECT * FROM activity_log WHERE userId = :userId ORDER BY timestamp DESC")
    fun getLogsForUser(userId: Long): Flow<List<ActivityLog>>
}
