package com.maretlagadi.welfarecentre.data.dao

import androidx.room.*
import com.maretlagadi.welfarecentre.data.entities.VolunteerShift
import kotlinx.coroutines.flow.Flow

@Dao
interface VolunteerShiftDao {
    @Insert
    suspend fun insert(shift: VolunteerShift): Long

    @Update
    suspend fun update(shift: VolunteerShift)

    @Query("SELECT * FROM volunteer_shifts WHERE volunteerId = :volunteerId")
    fun getShiftsForVolunteer(volunteerId: Long): Flow<List<VolunteerShift>>
}
