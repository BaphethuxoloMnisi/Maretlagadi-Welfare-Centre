package com.maretlagadi.welfarecentre.data.dao

import androidx.room.*
import com.maretlagadi.welfarecentre.data.entities.Volunteer
import kotlinx.coroutines.flow.Flow

@Dao
interface VolunteerDao {
    @Insert
    suspend fun insert(volunteer: Volunteer): Long

    @Update
    suspend fun update(volunteer: Volunteer)

    @Query("SELECT * FROM volunteers WHERE userId = :userId LIMIT 1")
    suspend fun findByUserId(userId: Long): Volunteer?

    @Query("SELECT * FROM volunteers WHERE volunteerId = :volunteerId LIMIT 1")
    suspend fun findById(volunteerId: Long): Volunteer?

    @Query("SELECT * FROM volunteers ORDER BY dateRegistered DESC")
    fun getAllVolunteers(): Flow<List<Volunteer>>

    @Delete
    suspend fun delete(volunteer: Volunteer)
}
