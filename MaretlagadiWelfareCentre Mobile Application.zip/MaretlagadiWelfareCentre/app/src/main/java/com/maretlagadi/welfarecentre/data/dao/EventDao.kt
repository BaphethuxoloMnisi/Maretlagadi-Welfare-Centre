package com.maretlagadi.welfarecentre.data.dao

import androidx.room.*
import com.maretlagadi.welfarecentre.data.entities.Event
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Insert
    suspend fun insert(event: Event): Long

    @Update
    suspend fun update(event: Event)

    @Delete
    suspend fun delete(event: Event)

    @Query("SELECT * FROM events ORDER BY date ASC")
    fun getAllEvents(): Flow<List<Event>>

    @Query("SELECT * FROM events WHERE programmeId = :programmeId ORDER BY date ASC")
    fun getEventsForProgramme(programmeId: Long): Flow<List<Event>>

    @Query("SELECT * FROM events WHERE eventId = :eventId LIMIT 1")
    suspend fun findById(eventId: Long): Event?

    @Query("SELECT COUNT(*) FROM events")
    suspend fun count(): Int
}
