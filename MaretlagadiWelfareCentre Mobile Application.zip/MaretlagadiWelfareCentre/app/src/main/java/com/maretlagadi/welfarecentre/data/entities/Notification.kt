package com.maretlagadi.welfarecentre.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class NotificationType {
    REMINDER, UPDATE, OPPORTUNITY, ALERT, ANNOUNCEMENT
}

/**
 * notifications table - sent to a specific user, or broadcast (userId = null).
 * `type` drives both the icon shown and the All/Unread/Updates/Alerts tabs
 * on the Notifications screen.
 */
@Entity(tableName = "notifications")
data class Notification(
    @PrimaryKey(autoGenerate = true) val notificationId: Long = 0,
    val userId: Long?,
    val title: String,
    val message: String,
    val type: NotificationType = NotificationType.ANNOUNCEMENT,
    val date: Long = System.currentTimeMillis(),
    val status: String = "UNREAD"
)
