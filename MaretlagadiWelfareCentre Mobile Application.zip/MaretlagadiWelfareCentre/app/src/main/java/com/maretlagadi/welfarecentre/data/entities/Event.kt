package com.maretlagadi.welfarecentre.data.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

/**
 * events table - each event belongs to a programme (programme_id FK).
 */
@Entity(
    tableName = "events",
    foreignKeys = [
        ForeignKey(
            entity = Programme::class,
            parentColumns = ["programmeId"],
            childColumns = ["programmeId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Event(
    @PrimaryKey(autoGenerate = true) val eventId: Long = 0,
    val programmeId: Long,
    val name: String,
    val date: String,
    val location: String
)
