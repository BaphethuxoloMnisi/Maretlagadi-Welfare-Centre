package com.maretlagadi.welfarecentre.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ShiftStatus {
    PENDING,
    CONFIRMED,
    COMPLETED,
    CANCELLED
}

/**
 * volunteer_shifts table - manages the relationship between volunteers and events.
 */
@Entity(tableName = "volunteer_shifts")
data class VolunteerShift(
    @PrimaryKey(autoGenerate = true) val shiftId: Long = 0,
    val volunteerId: Long,
    val eventId: Long,
    val status: ShiftStatus = ShiftStatus.PENDING
)
