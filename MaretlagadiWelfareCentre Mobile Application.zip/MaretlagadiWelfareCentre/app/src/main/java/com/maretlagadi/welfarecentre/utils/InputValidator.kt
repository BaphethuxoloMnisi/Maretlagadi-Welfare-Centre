package com.maretlagadi.welfarecentre.utils

import android.util.Patterns

/**
 * Centralised client-side validation used across registration, login,
 * volunteer registration and the contact form, matching the validation
 * requirements described in section 1.2 (User Registration and Login).
 */
object InputValidator {

    fun isValidEmail(email: String): Boolean =
        email.isNotBlank() && Patterns.EMAIL_ADDRESS.matcher(email).matches()

    fun isValidPhone(phone: String): Boolean =
        phone.isNotBlank() && phone.length in 7..15 && phone.all { it.isDigit() || it == '+' || it == ' ' }

    /** Requires at least 8 characters, one letter and one number. */
    fun isValidPassword(password: String): Boolean {
        if (password.length < 8) return false
        val hasLetter = password.any { it.isLetter() }
        val hasDigit = password.any { it.isDigit() }
        return hasLetter && hasDigit
    }

    fun isNotBlank(value: String): Boolean = value.trim().isNotEmpty()
}
