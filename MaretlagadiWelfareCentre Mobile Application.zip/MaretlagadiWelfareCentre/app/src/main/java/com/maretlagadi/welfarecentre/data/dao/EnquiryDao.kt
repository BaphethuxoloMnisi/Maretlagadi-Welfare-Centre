package com.maretlagadi.welfarecentre.data.dao

import androidx.room.*
import com.maretlagadi.welfarecentre.data.entities.EnquiryMessage
import kotlinx.coroutines.flow.Flow

@Dao
interface EnquiryDao {
    @Insert
    suspend fun insert(message: EnquiryMessage): Long

    @Update
    suspend fun update(message: EnquiryMessage)

    @Query("SELECT * FROM messages ORDER BY dateSent DESC")
    fun getAllMessages(): Flow<List<EnquiryMessage>>
}
