package com.maretlagadi.welfarecentre.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    PUBLIC_USER,
    VOLUNTEER,
    ADMIN
}

/**
 * users table
 * Stores account information and role, matching the "users" table
 * described in the Technical Documentation (2.3 Database Design).
 * `lastLoginAt` backs the admin-facing login activity view.
 */
@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val userId: Long = 0,
    val name: String,
    val email: String,
    val phone: String,
    val passwordHash: String,
    val passwordSalt: String,
    val role: UserRole = UserRole.PUBLIC_USER,
    val dateRegistered: Long = System.currentTimeMillis(),
    val lastLoginAt: Long? = null
)
